insert into car_rental_system.reservations (reservation_id, customer_id, pickup_location_id, dropoff_location_id, pickup_date, dropoff_date, car_id, insurance_id)
values  (1, 1, 1, 2, '2023-06-30', '2023-07-03', 1, 1),
        (2, 2, 2, 3, '2023-07-12', '2023-07-22', 5, 2),
        (3, 3, 5, 1, '2023-08-01', '2023-08-13', 4, 3),
        (4, 5, 3, 7, '2023-08-11', '2023-08-20', 6, 1),
        (5, 4, 6, 4, '2023-06-30', '2023-07-08', 2, 3);