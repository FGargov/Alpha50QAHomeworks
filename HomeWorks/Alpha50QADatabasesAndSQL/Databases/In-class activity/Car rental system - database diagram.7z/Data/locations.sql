insert into car_rental_system.locations (location_id, city)
values  (1, 'Sofia'),
        (2, 'Plovdiv'),
        (3, 'Varna'),
        (4, 'Burgas'),
        (5, 'Ruse'),
        (6, 'Veliko Turnovo'),
        (7, 'Blagoevgrad');