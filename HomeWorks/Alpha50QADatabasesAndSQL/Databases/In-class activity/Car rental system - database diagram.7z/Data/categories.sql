insert into car_rental_system.categories (category_id, category_name)
values  (1, 'Small'),
        (2, 'Mid-size'),
        (3, 'Large'),
        (4, 'Limousines'),
        (5, 'Sport');