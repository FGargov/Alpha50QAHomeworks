insert into car_rental_system.customer (customer_id, first_name, last_name)
values  (1, 'Filip', 'Gargov'),
        (2, 'Ivan', 'Petrov'),
        (3, 'Kiril', 'Georgiev'),
        (4, 'Boyko', 'Borisov'),
        (5, 'Asen', 'Vassilev'),
        (6, 'Qsen', 'Gerginenov');