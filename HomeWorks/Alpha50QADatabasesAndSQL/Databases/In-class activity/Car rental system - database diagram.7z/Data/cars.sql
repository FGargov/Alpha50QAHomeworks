insert into car_rental_system.cars (car_id, brand, model, year, kilometers, color_id, category_id)
values  (1, 'Toyota', 'Corolla', 2019, 100000, 1, 2),
        (2, 'Honda', 'Civic', 2015, 151000, 3, 2),
        (3, 'Mitsubishi', 'Pajero', 2018, 125000, 2, 3),
        (4, 'Ford', 'Mustang', 2021, 44000, 5, 5),
        (5, 'Toyota', 'RAV4', 2023, 12000, 4, 2),
        (6, 'Nissan', 'X-Trail', 2022, 25000, 6, 3);