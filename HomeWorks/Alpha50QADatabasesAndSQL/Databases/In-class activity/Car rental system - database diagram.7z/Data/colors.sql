insert into car_rental_system.colors (color_id, color_name)
values  (1, 'White'),
        (2, 'Black'),
        (3, 'Red'),
        (4, 'Silver'),
        (5, 'Blue'),
        (6, 'Green');