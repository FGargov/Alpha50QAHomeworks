insert into car_rental_system.insurances (insurance_id, insurance_type, cost)
values  (1, 'Full Coverage', 30.00),
        (2, 'Collision Damage Waiver', 20.00),
        (3, 'Personal Accident Insurance', 15.00);