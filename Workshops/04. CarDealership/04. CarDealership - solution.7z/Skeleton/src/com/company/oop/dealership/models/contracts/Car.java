package com.company.oop.dealership.models.contracts;

public interface Car extends Vehicle {

    int getSeats();

}
