package com.company.oop.dealership.models.contracts;

public interface Motorcycle extends Vehicle {

    String getCategory();
}
