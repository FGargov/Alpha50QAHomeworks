package com.company.oop.dealership.models.contracts;

public interface Truck extends Vehicle {

    int getWeightCapacity();

}
