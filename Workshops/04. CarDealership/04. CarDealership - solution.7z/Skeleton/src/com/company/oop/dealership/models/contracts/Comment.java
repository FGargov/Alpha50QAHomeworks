package com.company.oop.dealership.models.contracts;

public interface Comment {

    String getContent();

    String getAuthor();

}
