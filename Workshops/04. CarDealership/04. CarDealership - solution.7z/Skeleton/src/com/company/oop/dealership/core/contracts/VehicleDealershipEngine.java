package com.company.oop.dealership.core.contracts;

public interface VehicleDealershipEngine {

    void start();

}
