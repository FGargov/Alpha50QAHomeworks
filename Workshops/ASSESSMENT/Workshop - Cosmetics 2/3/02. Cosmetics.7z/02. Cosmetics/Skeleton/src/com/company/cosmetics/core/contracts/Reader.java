package com.company.cosmetics.core.contracts;

public interface Reader {
    
    String readLine();
    
}
