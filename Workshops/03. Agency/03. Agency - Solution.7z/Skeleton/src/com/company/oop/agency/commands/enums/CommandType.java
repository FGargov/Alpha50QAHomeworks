package com.company.oop.agency.commands.enums;

public enum CommandType {
    CREATEBUS,
    CREATEAIRPLANE,
    CREATEJOURNEY,
    CREATETICKET,
    CREATETRAIN,
    LISTJOURNEYS,
    LISTTICKETS,
    LISTVEHICLES
}