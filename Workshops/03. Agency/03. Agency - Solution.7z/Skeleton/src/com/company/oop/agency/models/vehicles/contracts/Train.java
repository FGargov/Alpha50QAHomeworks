package com.company.oop.agency.models.vehicles.contracts;

public interface Train extends Vehicle {

    int getCarts();

}