package com.company.oop.agency.models.contracts;

public interface Printable {

    String getAsString();

}
