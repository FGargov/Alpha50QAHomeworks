package com.company.oop.agency.commands;

public class CommandsConstants {

    public static final String JOIN_DELIMITER = "####################";
    public static final String VEHICLE_CREATED_MESSAGE = "Vehicle with ID %d was created.";

}