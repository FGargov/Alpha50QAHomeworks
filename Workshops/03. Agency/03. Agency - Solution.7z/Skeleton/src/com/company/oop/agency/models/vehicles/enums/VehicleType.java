package com.company.oop.agency.models.vehicles.enums;

    public enum VehicleType {
        LAND,
        AIR,
        SEA
}