package com.company.cosmetics.models.contracts;

import com.company.cosmetics.models.common.ScentType;

public interface Cream extends Product {
    
    public ScentType getScent();
    
}
