package com.company.cosmetics;

import com.company.cosmetics.core.CosmeticsEngine;

public class Startup {
    
    public static void main(String[] args) {
        CosmeticsEngine engine = new CosmeticsEngine();
        engine.start();
    }
}
