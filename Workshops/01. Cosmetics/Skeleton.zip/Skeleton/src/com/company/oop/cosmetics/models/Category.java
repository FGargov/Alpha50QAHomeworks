package com.company.oop.cosmetics.models;

import com.company.oop.cosmetics.models.products.Product;

import java.util.ArrayList;
import java.util.List;

public class Category {
    private static final int NAME_MIN_LENGTH = 3;
    private static final int NAME_MAX_LENGTH = 10;
    private String name;
    private List<Product> products;
    
    public Category(String name) {
        this.setName(name);
        products = new ArrayList<>();
    }
    
    public List<Product> getProducts() {
        return new ArrayList<>(products);
    }
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        if (name == null || name.length() < NAME_MIN_LENGTH || name.length() > NAME_MAX_LENGTH) {
            throw new IllegalArgumentException("Name must be between 3 and 10 characters long.");
        }
        this.name = name;
    }
    
    public void addProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }

        this.products.add(product);
    }
    
    public void removeProduct(Product product) {
       if (product == null) {
           throw new IllegalArgumentException("Product cannot be null.");
       }
        if (!this.products.contains(product)){
            throw new IllegalArgumentException("Product not found in this category.");
        }

        this.products.remove(product);
    }
    
    public String print() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("#Category: %s%n", name));
        for (Product product : products) {
            sb.append(product.print());
        }
        if (products.isEmpty()) {
            sb.append("#No product in this category");
        }
        return sb.toString();
    }
}
